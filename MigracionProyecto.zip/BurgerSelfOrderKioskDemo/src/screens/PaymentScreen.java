package screens;

import demo.Context;
import demo.Menu;
import java.util.ArrayList;
import javax.naming.CommunicationException;
import products.IndividualProduct;

public class PaymentScreen implements KioskScreen {
    private static final int WAIT_TIME = 60;

    @Override
    public KioskScreen show(Context context) {
        // Limpiar pantalla
        this.clear(context);
        
        // Configurar el simulador para la pantalla de bienvenida
        context.getKiosk().setMessageMode(); // Modo abajo botones, descripción arriba
        context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(12)); // Título
        
        // Botones
        context.getKiosk().setOption('A', context.getTraductor().getCurrentDictionary().getFrase(13));
        context.getKiosk().setOption('B', context.getTraductor().getCurrentDictionary().getFrase(7));
        
        // Descripción
        context.getKiosk().setDescription(getProductosResumen(context) + "\n" + context.getTraductor().getCurrentDictionary().getFrase(15) + getTotalPrecio(context));
        
        // Esperar la selección del usuario
        char selection = context.getKiosk().waitEvent(WAIT_TIME);

        // Obtener la información que vamos a mostrar
        if (selection == '1') {
            context.getKiosk().retainCreditCard(false);
            try {
                boolean ok = context.getBank().doOperation(context.getKiosk().getCardNumber(), getTotalPrecio(context));
                this.clear(context);
                
                if (ok) {
                    context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(30));
                    context.getKiosk().setDescription(context.getTraductor().getCurrentDictionary().getFrase(31));
                    context.getKiosk().expelCreditCard(100);
                    
                    // Creación del ticket e impresión
                    ArrayList<String> ticketText = new ArrayList<>();
                    ticketText.add(context.getTraductor().getCurrentDictionary().getFrase(32) + context.getOrderNumber());
                    ticketText.add(getProductosResumen(context));
                    ticketText.add(context.getTraductor().getCurrentDictionary().getFrase(15) + getTotalPrecio(context));
                    
                    context.getKiosk().print(ticketText);
                } else {
                    context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(33));
                    context.getKiosk().setDescription(context.getTraductor().getCurrentDictionary().getFrase(34));
                    context.getKiosk().expelCreditCard(100);
                }
            } catch (CommunicationException ex) {
                context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(35));
                context.getKiosk().setDescription(context.getTraductor().getCurrentDictionary().getFrase(36));
            }
        }

        // Manejar la selección del usuario
        return handleSelection(selection, context);
    }

    // Función para limpiar la información
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }

    private String getProductosResumen(Context context) {
        StringBuilder resumen = new StringBuilder();
        int totalPrecio = 0;
        
        // Obtener todos los productos del pedido
        for (Object product : context.getOrder().getProducts()) {
            if (product instanceof IndividualProduct) {
                // Producto individual
                IndividualProduct individualProduct = (IndividualProduct) product;
                resumen.append(context.getTraductor().getCurrentDictionary().getFrase(16)).append(individualProduct.getName()).append("\n");
            } else if (product instanceof Menu) {
                Menu menu = (Menu) product;
                resumen.append(context.getTraductor().getCurrentDictionary().getFrase(14));
                resumen.append("--");
                for (IndividualProduct individualProduct : menu.getProducts()) {
                    resumen.append(individualProduct.getName()).append("--");
                }
                resumen.append("\n");
            }
        }
        return resumen.toString(); // Devolver el resumen en forma de String
    }

    private int getTotalPrecio(Context context) {
        int totalPrecio = 0;

        // Obtener todos los productos del pedido
        for (Object product : context.getOrder().getProducts()) {
            if (product instanceof IndividualProduct) {
                // Producto individual
                IndividualProduct individualProduct = (IndividualProduct) product;
                totalPrecio += individualProduct.getPrice(); // Sumar el precio del producto individual
            } else if (product instanceof Menu) {
                Menu menu = (Menu) product;
                // Sumar el precio del menú, el descuento se selecciona en MenuScreen
                totalPrecio += menu.getPrice();
            }
        }

        return totalPrecio; // Retornar el total de los precios sumados
    }

    /**
     * Maneja la opción seleccionada por el usuario y devuelve la siguiente pantalla.
     *
     * @param selection Caracter seleccionado por el usuario
     * @param context Contexto del programa
     * @return La siguiente pantalla que se debe mostrar
     */
    private KioskScreen handleSelection(char selection, Context context) {
        KioskScreen nextScreen = null;

        switch (selection) {
            case 'A':
                // Navegar a la pantalla de pedidos
                nextScreen = new OrderScreen();
                break;
            case 'B':
                // Navegar a la pantalla de bienvenida
                nextScreen = new WelcomeScreen();
                break;
            default:
                // En caso de una opción no válida, volver a la pantalla de bienvenida
                System.out.println("Hola!! Hay alguien ahí?");
                nextScreen = new WelcomeScreen();
                break;
        }

        return nextScreen;
    }
}
