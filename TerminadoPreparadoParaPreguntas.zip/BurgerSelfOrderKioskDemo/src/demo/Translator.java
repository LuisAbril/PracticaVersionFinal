
package demo;

import java.util.HashMap;
import java.util.Map;

public class Translator {
    private Map <Integer,String> palabras;

    
    public Translator() {
        palabras = new HashMap <>();
    }

    public String getFrase(int x) {
        return palabras.get(x);
    }

    public void setPalabras(Integer key, String value) {
        palabras.put(key, value);
    }
    
    
    
    
}
