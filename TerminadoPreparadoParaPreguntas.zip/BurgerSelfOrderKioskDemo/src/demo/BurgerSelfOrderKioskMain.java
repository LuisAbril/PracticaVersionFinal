package demo;


import java.io.IOException;

public class BurgerSelfOrderKioskMain {
    private final KioskManager manager;
    private final Context context;

    // Constructor initializes the Context and KioskManager
    public BurgerSelfOrderKioskMain() throws IOException {
        this.context = new Context(); // Initialize the application context
        this.manager = new KioskManager(context); // Pass context to KioskManager
    }

    // The main execution flow of the kiosk
    public void run() {
        try {
            // Start the kiosk with the WelcomeScreen
            manager.start(); 
        } catch (IOException e) {
            System.err.println("Error during kiosk operation: " + e.getMessage());
        }
    }

    // Entry point of the application
    public static void main(String[] args) {
        try {
            // Create and run the kiosk
            BurgerSelfOrderKioskMain kiosk = new BurgerSelfOrderKioskMain();
            kiosk.run();
        } catch (IOException e) {
            System.err.println("Error starting kiosk: " + e.getMessage());
        }
    }
}
