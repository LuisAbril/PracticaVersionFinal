package demo;

import products.IndividualProduct;
import java.util.ArrayList;

public class Menu implements Product {
    private double discount;
    private ArrayList<IndividualProduct> menuProducts;
    
    
    //constructor con descuento
    public Menu(int discount) {
        this.discount = discount;
        this.menuProducts = new ArrayList<>();
    }
    //constructor vacio
    public Menu() {
        menuProducts = new ArrayList<>();
    }
    
    
    //funcion para añadir producto al menu
    public void addProduct(IndividualProduct product) {
        menuProducts.add(product);
    }
    
    
    
    
    
    //getters y setters usados (creo que hay alguno que no se usa pero no lo elimino por si acaso)
    @Override
    public int getPrice() {
        int totalPrice = 0;
        for (IndividualProduct product : menuProducts) {
            totalPrice += product.getPrice();
        }
        int precioFinalMenu = (int) (totalPrice * (1- (discount / 100)));
        return precioFinalMenu;  // Apply discount
    }
    
    public IndividualProduct getProduct(int numero) {
        if (numero >= 0 && numero < menuProducts.size()) {
            return menuProducts.get(numero);
        }
        return null;
    }
    
    public ArrayList<IndividualProduct> getProducts() {
        ArrayList<IndividualProduct> nombres = new ArrayList<>();
        for (int i = 0;i<3;i++) {
            nombres.add(menuProducts.get(i));
        }
        return nombres;
    }
    
    @Override
    public String getName() {
        StringBuilder name = new StringBuilder();
        for (int i=0; i<3;i++) {
            name.append(menuProducts.get(i).getName());
        }
        return name.toString(); 
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }
    
   

   
}