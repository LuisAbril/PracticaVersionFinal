package demo;

import screens.WelcomeScreen;
import java.io.IOException;

/**
 * Clase que gestiona el flujo inicial del kiosco.
 * Se encarga de iniciar el programa y mostrar la pantalla de bienvenida.
 */
public class KioskManager {
    private final Context ctxt; // Contexto que contiene todas las dependencias del kiosco

    //constructor
    public KioskManager(Context ctxt) {
        this.ctxt = ctxt;
    }

    /**
     * Método que inicia el programa según el diagrama de secuencia.
     * @throws java.io.IOException
     */
    public void start() throws IOException {
        // Crear y mostrar la pantalla de bienvenida (WelcomeScreen)
        WelcomeScreen welScreen = new WelcomeScreen();
        welScreen.show(ctxt);
    }
}
