package screens;

import demo.Context;

public class IdiomScreen implements KioskScreen {
    private static final int WAIT_TIME = 60;
    
    @Override
    public void show(Context context) {
        // Clear the screen first
        this.clear(context);
        
        // Set to menu mode for options
        context.getKiosk().setMenuMode();
        context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(24));
        
        // Configure buttons
        configureScreenButtons(context);
        
        // Wait for user selection
        char option = context.getKiosk().waitEvent(WAIT_TIME);
        
        // Handle language selection
        handleLanguageSelection(option, context);
        
        // Return to welcome screen
        WelcomeScreen welcomeScreen = new WelcomeScreen();
        welcomeScreen.show(context);
    }
    
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }
    
    private void configureScreenButtons(Context context) {
        context.getKiosk().setOption('A', context.getTraductor().getCurrentDictionary().getFrase(25));
        context.getKiosk().setOption('B', context.getTraductor().getCurrentDictionary().getFrase(26));
        context.getKiosk().setOption('C', context.getTraductor().getCurrentDictionary().getFrase(27));
        context.getKiosk().setOption('D', context.getTraductor().getCurrentDictionary().getFrase(28));
        
    }
    
    private void handleLanguageSelection(char option, Context context) {
        switch (option) {
            case 'A' -> {
                context.getTraductor().setCurrentIdiom("esp");}
            case 'B' -> {
                context.getTraductor().setCurrentIdiom("fra");}
            case 'D' -> {
                context.getTraductor().setCurrentIdiom("ing");}
            case 'C' -> {
                context.getTraductor().setCurrentIdiom("ale");}
            
        }
    }
    }
    
    