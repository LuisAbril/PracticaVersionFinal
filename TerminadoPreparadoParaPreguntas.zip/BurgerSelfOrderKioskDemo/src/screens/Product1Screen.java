package screens;

import demo.Context;
import java.util.ArrayList;
import products.IndividualProduct;

public class Product1Screen implements KioskScreen {
    private static final int WAIT_TIME = 60;
    private ArrayList<IndividualProduct> productos;
    int indiceActual;

    @Override
    public void show(Context context) {
        //limpiar pantalla
        this.clear(context);
        //inicializar el array de hamburguesas
        productos = new ArrayList<>();
        indiceActual=0;
        // Configurar el simulador para la pantalla de pedido
        context.getKiosk().setMenuMode();   //Modo1 (botones a la izquierda img a la derecha)
        context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(20));   //titulo
        //botones 
        context.getKiosk().setOption('C', context.getTraductor().getCurrentDictionary().getFrase(11));
        context.getKiosk().setOption('D', context.getTraductor().getCurrentDictionary().getFrase(9));
        context.getKiosk().setOption('E', context.getTraductor().getCurrentDictionary().getFrase(7));
        context.getKiosk().setOption('G', "<");
        context.getKiosk().setOption('H', ">");

        //Inicializar la informacion que vamos a usar
        for (int i=0; i< context.getMenu().getSection(0).getProducts().size();i++){
            IndividualProduct producto = context.getMenu().getSection(0).getProduct(i);
            productos.add(producto);
        }
        
        context.getKiosk().setDescription(productos.get(0).getName()+"\n"+productos.get(0).getDescription()+"\n"+productos.get(0).getPrice());
        context.getKiosk().setImage("src/"+productos.get(0).getImage());
        // Esperar la selección del usuario
        
        
        //bucle para que no se quede atascado despues de presionar una vez no dejen de funcionar los botones
        while (true) {
            char selection = context.getKiosk().waitEvent(WAIT_TIME);
            handleSelection(selection, context, productos);
        }
        // Manejar la selección del usuario
        
    }
    
    //funcion para limpiar la informacion
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }
    
    
    private void actualizarPantalla(Context context, ArrayList<IndividualProduct> productos){
                context.getKiosk().setDescription(productos.get(indiceActual).getName()+"\n"+productos.get(indiceActual).getDescription()+"\n"+productos.get(indiceActual).getPrice());
                context.getKiosk().setImage("src/"+productos.get(indiceActual).getImage());
    }
    
    /**
     * Maneja la opción seleccionada por el usuario.
     */
    private void handleSelection(char selection, Context context, ArrayList<IndividualProduct> productos) {
        switch (selection) {
            case 'C' -> {
                context.getOrder().addfProduct(productos.get(indiceActual));
                OrderScreen orderScreen = new OrderScreen();
                orderScreen.show(context);
            }
            case 'D' -> {
            // Navegar a la pantalla para añadir un producto individual
                TypeProductScreen typeProductScreen = new TypeProductScreen();
                typeProductScreen.show(context);}
            case 'E' -> {
            // Navegar a la pantalla de pago
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }
            case 'G' -> {
                indiceActual--;
                if (indiceActual<0){indiceActual=productos.size()-1;}
                actualizarPantalla(context,productos);
            }
            case 'H' -> {
                indiceActual++;
                if (indiceActual>productos.size()-1){indiceActual=0;}
                actualizarPantalla(context,productos);
            }
            default -> {
                System.out.println("Hola!! Hay alguien ahi?");
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }

        }
    }
}
