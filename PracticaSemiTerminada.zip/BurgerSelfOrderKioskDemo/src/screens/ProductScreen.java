package screens;

import demo.Context;
import java.util.ArrayList;
import products.IndividualProduct;

public class ProductScreen implements KioskScreen {
    private static final int WAIT_TIME = 60;
    private ArrayList<IndividualProduct> productos;
    private int tipoProd;
    private int indiceActual;

    @Override
    public KioskScreen show(Context context) {
        productos = new ArrayList<>();
        indiceActual = 0;
        
// Inicializar la información que vamos a usar
        for (int i = 0; i < context.getMenu().getSection(tipoProd).getProducts().size(); i++) {
            IndividualProduct producto = context.getMenu().getSection(tipoProd).getProduct(i);
            productos.add(producto);
        }
        
        configureButtons(context);

        // Esperar la selección del usuario y devolver la pantalla correspondiente
        while (true) {
            char selection = context.getKiosk().getKiosk().waitEvent(WAIT_TIME);
            KioskScreen nextScreen = handleSelection(selection, context, productos);
            if (nextScreen != null) {
                return nextScreen;  // Regresar la siguiente pantalla a mostrar
            }
        }
    }

    private void configureButtons(Context context) {
        this.clear(context);
        context.getKiosk().setMode(0);
        context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(20));
        context.getKiosk().setOption('C', context.getTraductor().getCurrentDictionary().getFrase(11));
        context.getKiosk().setOption('D', context.getTraductor().getCurrentDictionary().getFrase(9));
        context.getKiosk().setOption('E', context.getTraductor().getCurrentDictionary().getFrase(7));
        context.getKiosk().setOption('G', "<");
        context.getKiosk().setOption('H', ">");
        int dineroTotal = productos.get(0).getPrice();
        double conversion = dineroTotal/100.0;
        context.getKiosk().setDescription(productos.get(0).getName() + "\n" + productos.get(0).getDescription() + "\n" + conversion +"€");
        context.getKiosk().setImage("src/" + productos.get(0).getImage());
    }

    // Función para limpiar la pantalla
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }

    // Actualizar la pantalla con la información del producto actual
    private void actualizarPantalla(Context context, ArrayList<IndividualProduct> productos) {
        int dineroTotal = productos.get(indiceActual).getPrice();
        double conversion = dineroTotal/100.0;
        context.getKiosk().setDescription(productos.get(indiceActual).getName() + "\n" + productos.get(indiceActual).getDescription() + "\n" + conversion+"€");
        context.getKiosk().setImage("src/" + productos.get(indiceActual).getImage());
    }

    /**
     * Maneja la opción seleccionada por el usuario y devuelve la siguiente pantalla.
     */
    private KioskScreen handleSelection(char selection, Context context, ArrayList<IndividualProduct> productos) {
        switch (selection) {
            case 'C' -> {
                context.getOrder().addfProduct(productos.get(indiceActual));
                return new OrderScreen();  // Ir a la pantalla de orden
            }
            case 'D' -> {
                // Navegar a la pantalla para añadir un producto individual
                return new TypeProductScreen();
            }

            case 'E' -> {
                // Navegar a la pantalla de bienvenida
                return new WelcomeScreen();
            }

            case 'G' -> {
                // Navegar hacia atrás entre los productos
                indiceActual--;
                if (indiceActual < 0) {
                    indiceActual = productos.size() - 1;
                }
                actualizarPantalla(context, productos);
                return null;  // No hace nada más, sigue en la misma pantalla
            }
            case 'H' -> {
                // Navegar hacia adelante entre los productos
                indiceActual++;
                if (indiceActual >= productos.size()) {
                    indiceActual = 0;
                }
                actualizarPantalla(context, productos);
                return null;  // No hace nada más, sigue en la misma pantalla
            }
            default -> {
                System.out.println("¡Hola! ¿Hay alguien ahí?");
                return new WelcomeScreen();  // Volver a la pantalla de bienvenida
            }
        }
    }

    public ProductScreen(int tipoProd) {
        this.tipoProd = tipoProd;
    }

    
    
}
