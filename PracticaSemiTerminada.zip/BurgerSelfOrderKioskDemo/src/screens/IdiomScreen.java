package screens;

import demo.Context;

public class IdiomScreen implements KioskScreen {
    private static final int WAIT_TIME = 60;

    @Override
    public KioskScreen show(Context context) {
        // Configurar botones
        configureScreenButtons(context);
        
        // Iniciar temporizador y esperar a que se presione algo
        char option = context.getKiosk().getKiosk().waitEvent(WAIT_TIME);
        handleLanguageSelection(option, context);
        // Volver a welcomeScreen
        return new WelcomeScreen();
    }
    
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }
    
    private void configureScreenButtons(Context context) {
        this.clear(context);
        context.getKiosk().setMode(0);
        context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(24));
        context.getKiosk().setOption('A', context.getTraductor().getCurrentDictionary().getFrase(25));
        context.getKiosk().setOption('B', context.getTraductor().getCurrentDictionary().getFrase(26));
        context.getKiosk().setOption('C', context.getTraductor().getCurrentDictionary().getFrase(27));
        context.getKiosk().setOption('D', context.getTraductor().getCurrentDictionary().getFrase(28));
    }
    
    private void handleLanguageSelection(char option, Context context) {
        switch (option) {
            case 'A' -> context.getTraductor().setCurrentIdiom("esp");
            case 'B' -> context.getTraductor().setCurrentIdiom("fra");
            case 'C' -> context.getTraductor().setCurrentIdiom("ale");
            case 'D' -> context.getTraductor().setCurrentIdiom("ing");
        }
    }
}
