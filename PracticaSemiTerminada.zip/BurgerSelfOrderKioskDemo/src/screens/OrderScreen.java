package screens;

import demo.Context;

public class OrderScreen implements KioskScreen {
    private static final int WAIT_TIME = 60;

    @Override
    public KioskScreen show(Context context) {
        configureButtons(context);

        // Esperar la selección del usuario
        char selection = context.getKiosk().getKiosk().waitEvent(WAIT_TIME);

        // Manejar la selección del usuario y devolver la siguiente pantalla
        return handleSelection(selection, context);
    }

    
    
    private void configureButtons(Context context) {
        this.clear(context);
        context.getKiosk().setMode(0);
        context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(3));
        context.getKiosk().setOption('B', context.getTraductor().getCurrentDictionary().getFrase(4));  
        context.getKiosk().setOption('C', context.getTraductor().getCurrentDictionary().getFrase(5));
        context.getKiosk().setOption('D', context.getTraductor().getCurrentDictionary().getFrase(6));
        context.getKiosk().setOption('E', context.getTraductor().getCurrentDictionary().getFrase(7));
        context.getKiosk().setImage("src/PRODUCTOS/Pedido.png");
    }

    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }
    
    private KioskScreen handleSelection(char selection, Context context) {
        KioskScreen nextScreen;

        switch (selection) {
            case 'B' -> // Navegar a la pantalla para añadir un menú
                nextScreen = new MenuScreen();
            case 'C' -> // Navegar a la pantalla para añadir un producto individual
                nextScreen = new TypeProductScreen();
            case 'D' -> // Navegar a la pantalla de pago
                nextScreen = new PaymentScreen();
            case 'E' -> // Cancelar pedido y volver a la pantalla inicial
                nextScreen = new WelcomeScreen();
            default -> {
                // En caso de una opción no válida, volver a la pantalla inicial
                System.out.println("Hola!! Hay alguien ahi?");
                nextScreen = new WelcomeScreen();
            }
        }

        return nextScreen;
    }
}
