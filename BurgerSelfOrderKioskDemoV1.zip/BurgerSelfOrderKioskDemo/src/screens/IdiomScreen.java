package screens;

import demo.Context;

public class IdiomScreen implements KioskScreen {
    private static final int WAIT_TIME = 30;
    
    @Override
    public void show(Context context) {
        // Clear the screen first
        this.clear(context);
        
        // Set to menu mode for options
        context.getKiosk().setMenuMode();
        context.getKiosk().setTitle("Seleccione Idioma / Select Language");
        
        // Configure buttons
        configureScreenButtons(context);
        
        // Wait for user selection
        char option = context.getKiosk().waitEvent(WAIT_TIME);
        
        // Handle language selection
        handleLanguageSelection(option, context);
        
        // Return to welcome screen
        WelcomeScreen welcomeScreen = new WelcomeScreen();
        welcomeScreen.show(context);
    }
    
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }
    
    private void configureScreenButtons(Context context) {
        context.getKiosk().setOption('B', "Español");
        context.getKiosk().setOption('D', "English");
    }
    
    private void handleLanguageSelection(char option, Context context) {
        switch (option) {
            case 'B' -> System.out.println("CLICASTE ESPA");
                //context.getTranslator().setCurrentIdiom("es");
            case 'D' -> System.out.println("CLICASTE Eng");
            // context.getTranslator().setCurrentIdiom("en");
        }
    }
    }
    
    