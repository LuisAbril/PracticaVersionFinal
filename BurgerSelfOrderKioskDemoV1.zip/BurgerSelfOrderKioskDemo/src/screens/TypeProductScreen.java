package screens;

import demo.Context;

public class TypeProductScreen implements KioskScreen {
    private static final int WAIT_TIME = 30;

    @Override
    public void show(Context context) {
        //limpiar pantalla
        this.clear(context);
        // Configurar el simulador para la pantalla de pedido
        context.getKiosk().setMenuMode();
        context.getKiosk().setTitle("Seleccione el tipo de producto:");
        context.getKiosk().setOption('B', context.getMenu().getSectionsNames(0));
        context.getKiosk().setOption('C', context.getMenu().getSectionsNames(1));
        context.getKiosk().setOption('D', context.getMenu().getSectionsNames(2));
        context.getKiosk().setOption('E', "Volver");

        // Esperar la selección del usuario
        char selection = context.getKiosk().waitEvent(WAIT_TIME);

        // Manejar la selección del usuario
        handleSelection(selection, context);
    }
    //funcion para limpiar la informacion
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }
    /**
     * Maneja la opción seleccionada por el usuario.
     *
     * @param selection Caracter seleccionado por el usuario
     * @param context Contexto del programa
     */
    private void handleSelection(char selection, Context context) {
        switch (selection) {
            case 'B' -> System.out.println("Opcion seleccionada: Tipo0");
            
            case 'C' -> System.out.println("Opcion seleccionada: Tipo1");
            
            case 'D' -> System.out.println("Opcion seleccionada: Tipo2");
            
            case 'E' -> {
                System.out.println("Opcion seleccionada: Volver");
                // Cancelar pedido y volver a la pantalla inicial
                OrderScreen orderScreen = new OrderScreen();
                orderScreen.show(context);
            }
            default -> {
                System.out.println("Seleccion no valida. Recargando pantalla...");
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }
        }
    }
}

