package screens;

import demo.Context;

public class WelcomeScreen implements KioskScreen {
    private static final int WAIT_TIME = 30;

    @Override
    public void show(Context context) {
        //limpiar pantalla
        this.clear(context);
        // Configurar el simulador para la pantalla de bienvenida
        context.getKiosk().setMenuMode();
        context.getKiosk().setTitle("URJC Burger - Bienvenido");
        context.getKiosk().setOption('B', "Nuevo pedido");
        context.getKiosk().setOption('D', "Cambiar idioma");
        context.getKiosk().setImage("Logo.png");

        // Esperar la selección del usuario
        char selection = context.getKiosk().waitEvent(WAIT_TIME);

        // Manejar la selección del usuario
        switch (selection) {
            case 'B' -> {
                System.out.println("Navegar a la pantalla de pedido...");
                OrderScreen orderScreen= new OrderScreen();
                orderScreen.show(context);
            }
            case 'D' -> {
                System.out.println("Navegar a la pantalla de idioma...");
                IdiomScreen idiomScreen = new IdiomScreen();
                idiomScreen.show(context);
            }
            default -> {
                System.out.println("Seleccion no valida. Recargando pantalla...");
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }
        }
    }
    //funcion para limpiar la informacion
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }
}

 