package products;

import java.beans.XMLDecoder;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

public class MenuCard {
    //Atributos
    private ArrayList<MenuCardSection> sections;
    
    //Constructores
    public MenuCard() {
        this.sections = new ArrayList<>();
    }
    
    public MenuCard(ArrayList<MenuCardSection> sections) {
        this.sections = sections;
    }
    
    //Funcion para cargar los archivos del XML aportado 
    public MenuCard loadFromDisk(String filePath) {
        try (XMLDecoder decoder = new XMLDecoder(new FileInputStream(filePath))) {
            MenuCard menuCardLoaded = (MenuCard) decoder.readObject();
            decoder.close();
            return menuCardLoaded;
        } catch (IOException e) {
            return null;
        }
    }
    
    //Funcion para mostrar todas las secciones
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Carta del Menú:\n");
        for (MenuCardSection section : sections) {
            sb.append(section.toString()).append("\n");
        }
        return sb.toString();
    }
    
    // Getters y Setters
    
    
    //Con esto se obtiene el nombre de la seccion elegida mediante el Index (Se usa para la pantalla de seleccionar tipo en la pantalla TypeProductScreen)
    public String getSectionsNames(int i) {
        String nombreSect;
        nombreSect = sections.get(i).getName();
        return nombreSect;
    }
    
    public void setSections(ArrayList<MenuCardSection> sections) {
        this.sections = sections;
    }
    
    public MenuCardSection getSection(int index) {
        if (index >= 0 && index < sections.size()) {
            return sections.get(index);
        }
        return null;
    }
    
    public int getNumberOfSections() {
        return sections != null ? sections.size() : 0;
    }
    
    //add section de uml
    public void addSection(MenuCardSection section) {
        if (section != null) {
            if (sections == null) {
                sections = new ArrayList<>();
            }
            sections.add(section);
        }
    }
}
