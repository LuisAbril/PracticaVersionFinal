package demo;

import products.MenuCard;
import urjc.UrjcBankServer;
import sienens.BurgerSelfOrderKiosk;

import java.io.IOException;

public class Context {
    private BurgerSelfOrderKiosk kiosk;     //Simulador
    private UrjcBankServer bank;            //Banco
    private MenuCard menu;                  //MenuCargado del XML
    private TranslatorManager traductor;   //Transator 
    private Order pedido;                    //Informacion del pedido realizado
    private int orderNumber;                //Numero de pedido
    private int kiosknumber;                //Numero de kiosco (inventado?)
             

  
    
    
    public Context() throws IOException {
        this.kiosk = new BurgerSelfOrderKiosk(); // Inicializar el simulador
        this.bank = new UrjcBankServer();       // Inicializar el servidor del banco
        this.menu = new MenuCard();             // Inicializar el menú vacío
        this.traductor = new TranslatorManager();  //Inicializar el translator
        this.pedido = new Order();               //Inicializar el pedido
        this.orderNumber = 5;   //numerorandom
        this.kiosknumber = 1;   //numerorandom
        menu = this.loadMenu();                             // Cargar el menú desde el XML
    }
    //Cargar Productos en menu
    private MenuCard loadMenu() {
        String filePath = "src/products/archivos/Catalog.xml"; // Ajustar ruta según tu estructura
        MenuCard loadedMenu = menu.loadFromDisk(filePath);
        if (loadedMenu != null) {
            this.menu = loadedMenu;
            System.out.println("Menu cargado correctamente desde " + filePath);
            return loadedMenu;
        } else {
            System.err.println("Error al cargar el menú desde " + filePath);
            return loadedMenu;
        }
    }

    public BurgerSelfOrderKiosk getKiosk() {
        return kiosk;
    }

    public UrjcBankServer getBank() {
        return bank;
    }

    public MenuCard getMenu() {
        return menu;
    }
}
/*
    // Getter for the current order
    public Order getCurrentOrder() {
        return currentOrder;
    }

    // Setter for the current order
    public void setCurrentOrder(Order order) {
        this.currentOrder = order;
    }
}

    
   // public void createNewOrder() {
     //   this.currentOrder = new Order();
    //}
    
   // public TranslatorManager getTranslator() {
     //   return translator;
    //}
    
    //public String translate(String key) {
      //  return translator.getString(key);
  //  }
*/