package demo;

public class SelfOrderKiosk {
    private SimpleKiosk kiosk;

    public SelfOrderKiosk(SimpleKiosk kiosk) {
        this.kiosk = kiosk;
    }

    // Methods to delegate functionality to SimpleKiosk
    public void setOption(char key, String description) {
        kiosk.setOption(key, description);
    }

    public void setTitle(String title) {
        kiosk.setTitle(title);
    }

    public void setDescription(String description) {
        kiosk.setDescription(description);
    }

    public void setMode(int mode) {
        kiosk.setMode(mode);
    }

    public void setImage(String imagePath) {
        kiosk.setImage(imagePath);
    }

    public char waitEvent(int timeout) {
        return kiosk.waitEvent(timeout);
    }

    public void print(String message) {
        kiosk.print(message);
    }

    public void retainCard(boolean retain) {
        kiosk.retainCard(retain);
    }

    public void expelCreditCard(int reasonCode) {
        kiosk.expelCreditCard(reasonCode);
    }
}
