package demo;

import screens.WelcomeScreen;
import java.io.IOException;

/**
 * Clase que gestiona el flujo inicial del kiosco.
 * Se encarga de iniciar el programa y mostrar la pantalla de bienvenida.
 */
public class KioskManager {
    private Context ctxt; // Contexto que contiene todas las dependencias del kiosco

    /**
     * Constructor de KioskManager.
     * 
     * @param ctxt Contexto del programa con los datos inicializados
     */
    public KioskManager(Context ctxt) {
        this.ctxt = ctxt;
    }

    /**
     * Método que inicia el programa según el diagrama de secuencia.
     * Este método muestra la pantalla inicial del kiosco.
     *
     * @throws IOException Si ocurre algún problema al cargar recursos como el menú
     */
    public void start() throws IOException {
        // Crear y mostrar la pantalla de bienvenida (WelcomeScreen)
        WelcomeScreen welScreen = new WelcomeScreen();

        // Mostrar la pantalla de bienvenida utilizando el contexto del programa
        welScreen.show(ctxt);
    }
}
