package screens;

import demo.Context;

public class OrderScreen implements KioskScreen {
    private static final int WAIT_TIME = 60;

    @Override
    public void show(Context context) {
        //limpiar pantalla
        this.clear(context);
        // Configurar el simulador para la pantalla de pedido
        context.getKiosk().setMenuMode();   //Modo1 (botones a la izquierda img a la derecha)
        context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(3));   //titulo
        //botones
        context.getKiosk().setOption('B', context.getTraductor().getCurrentDictionary().getFrase(4));  
        context.getKiosk().setOption('C', context.getTraductor().getCurrentDictionary().getFrase(5));
        context.getKiosk().setOption('D', context.getTraductor().getCurrentDictionary().getFrase(6));
        context.getKiosk().setOption('E', context.getTraductor().getCurrentDictionary().getFrase(7));
        //imagen
        context.getKiosk().setImage("src/PRODUCTOS/Pedido.png");

        // Esperar la selección del usuario
        char selection = context.getKiosk().waitEvent(WAIT_TIME);

        // Manejar la selección del usuario
        handleSelection(selection, context);
    }
    //funcion para limpiar la informacion
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }
    /**
     * Maneja la opción seleccionada por el usuario.
     *
     * @param selection Caracter seleccionado por el usuario
     * @param context Contexto del programa
     */
    private void handleSelection(char selection, Context context) {
        switch (selection) {
            case 'B' -> {
                System.out.println("Anadir menú a pedido");
            // Navegar a la pantalla para añadir un menú
                MenuScreen menuScreen = new MenuScreen();
                menuScreen.show(context);
            }
            case 'C' -> {
                System.out.println("Anadir producto individual a pedido");
            // Navegar a la pantalla para añadir un producto individual
                TypeProductScreen typeProductScreen = new TypeProductScreen();
                typeProductScreen.show(context);}
            case 'D' -> {
                System.out.println("Finalizar pedido y pagar");
            // Navegar a la pantalla de pago
                PaymentScreen paymentScreen = new PaymentScreen();
                paymentScreen.show(context);
            }
            case 'E' -> {
                System.out.println("Cancelar pedido");
                // Cancelar pedido y volver a la pantalla inicial
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }
            default -> {
                System.out.println("Demasiado tiempo AFK");
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }
        }
    }
}
