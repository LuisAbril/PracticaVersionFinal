package screens;

import demo.Context;
import demo.Order;

public class WelcomeScreen implements KioskScreen {
    private static final int WAIT_TIME = 60;

    @Override
    public void show(Context context) {
        //limpiar pantalla
        this.clear(context);
        // Configurar el simulador para la pantalla de bienvenida
        context.getKiosk().setMenuMode();
        context.getKiosk().setTitle("URJC Burger - "+ context.getTraductor().getCurrentDictionary().getFrase(0));
        context.getKiosk().setOption('B', context.getTraductor().getCurrentDictionary().getFrase(1));
        context.getKiosk().setOption('D', context.getTraductor().getCurrentDictionary().getFrase(2));
        context.getKiosk().setImage("src/PRODUCTOS/Logo.png");
        //Si hay un pedido con productos se reinicia
        Order pedidoNuevo = new Order();
        context.setPedido(pedidoNuevo);
        // Esperar la selección del usuario
        char selection = context.getKiosk().waitEvent(WAIT_TIME);

        // Manejar la selección del usuario
        switch (selection) {
            case 'B' -> {
                System.out.println("Iniciar pedido");
                OrderScreen orderScreen= new OrderScreen();
                orderScreen.show(context);
            }
            case 'D' -> {
                System.out.println("Cambiar idioma");
                IdiomScreen idiomScreen = new IdiomScreen();
                idiomScreen.show(context);
            }
            default -> {
                System.out.println("Hola? Alguien ahí?");
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }
        }
    }
    //funcion para limpiar la informacion
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }
}

 