package screens;

import demo.Context;
import demo.Menu;
import java.util.ArrayList;
import java.util.List;
import javax.naming.CommunicationException;
import products.IndividualProduct;

public class PaymentScreen implements KioskScreen {
    private static final int WAIT_TIME = 60;

    @Override
    public void show(Context context) {
        //limpiar pantalla
        this.clear(context);
        // Configurar el simulador para la pantalla de bienvenida
        context.getKiosk().setMessageMode();//modo abajo botones descripcion arriba
        context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(12));//titulo
        //botones
        context.getKiosk().setOption('A', context.getTraductor().getCurrentDictionary().getFrase(13));
        context.getKiosk().setOption('B', context.getTraductor().getCurrentDictionary().getFrase(7));
        context.getKiosk().setDescription(getProductosResumen(context)+"\n"+context.getTraductor().getCurrentDictionary().getFrase(15)+getTotalPrecio(context));
        char c = context.getKiosk().waitEvent(WAIT_TIME);
        //Obtener la información que vamos a mostrar
        
        
        // Esperar la selección del usuario
        char selection = context.getKiosk().waitEvent(WAIT_TIME);
        
        
        //Todo sobre la introduccion de la tarjeta
        if (c=='1'){
            context.getKiosk().retainCreditCard(false);
            try{
                boolean ok = context.getBank().doOperation(context.getKiosk().getCardNumber(),getTotalPrecio(context));
                
                if(ok){
                    this.clear(context);
                    context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(30));
                    context.getKiosk().setDescription(context.getTraductor().getCurrentDictionary().getFrase(31));
                    context.getKiosk().expelCreditCard(15);
                    
                    //crwcion del ticket e impresion
                    ArrayList<String> ticketText = new ArrayList<>();
                            ticketText.add(context.getTraductor().getCurrentDictionary().getFrase(32)+context.getOrderNumber());
                            ticketText.add(getProductosResumen(context));
                            ticketText.add(context.getTraductor().getCurrentDictionary().getFrase(15)+getTotalPrecio(context));
                            
                            context.getKiosk().print(ticketText);
                } else {
                    context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(33));
                    context.getKiosk().setDescription(context.getTraductor().getCurrentDictionary().getFrase(34));
                    context.getKiosk().expelCreditCard(15);
                
                
                }
                
                
            }catch(CommunicationException ex){
                context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(35));
                context.getKiosk().setDescription(context.getTraductor().getCurrentDictionary().getFrase(36));
            }
        }
        
        
        
        
        // Manejar la selección del usuario
        switch (selection) {
            case 'A' -> {
                System.out.println("Volver a la pantalla de pedido");
                OrderScreen orderScreen= new OrderScreen();
                orderScreen.show(context);
            }
            case 'B' -> {
                System.out.println("Cancelar el pedido");
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }
            default -> {
                System.out.println("Demasiado tiempo AFK");
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }
        }
    }
    //funcion para limpiar la informacion
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }
    
    
    private String getProductosResumen(Context context) {
        StringBuilder resumen = new StringBuilder();
        int totalPrecio=0;
        // Obtener todos los productos del pedido
        for (Object product : context.getOrder().getProducts()) {
            if (product instanceof IndividualProduct) {
                // Producto individual
                IndividualProduct individualProduct = (IndividualProduct) product;
                resumen.append(context.getTraductor().getCurrentDictionary().getFrase(16)).append(individualProduct.getName()).append("\n");
            }else if (product instanceof Menu) {
                Menu menu = (Menu) product;
                resumen.append(context.getTraductor().getCurrentDictionary().getFrase(14));
                
                for (IndividualProduct individualProduct : menu.getProducts()){
                resumen.append(individualProduct.getName()).append(" ");
                }
                resumen.append("\n");
            }
        }
        return resumen.toString();  // Devolver el resumen en forma de String
    }
    
    private int getTotalPrecio(Context context) {
    int totalPrecio = 0;

    // Obtener todos los productos del pedido
    for (Object product : context.getOrder().getProducts()) {
        if (product instanceof IndividualProduct) {
            // Producto individual
            IndividualProduct individualProduct = (IndividualProduct) product;
            totalPrecio += individualProduct.getPrice();  // Sumar el precio del producto individual
        } else if (product instanceof Menu) {
            Menu menu = (Menu) product;
            // Sumar el precio del menu, el descuento se selecciona en MenuScreen
            totalPrecio += menu.getPrice();
            
        }
    }

    return totalPrecio;  // Retornar el total de los precios sumados
}

}