package demo;
import java.util.ArrayList;

public class Order {
    private int orderNumber;
    private ArrayList<Product> products;
    
    
   
    
    //añadir producto al pedido (pueden ser tanto individuales como menus)
    public void addfProduct(Product producto) {
        if (producto != null) {
            products.add(producto);
        }
    }
   
    
    
    
    
     //Constructores
    public Order(int orderNumber) {
        this.orderNumber = orderNumber;
        this.products = new ArrayList<>();
    }

    public Order() {
        this.products = new ArrayList<>();
    }
    
    
    
    //getters 
    
    //este getter creo que no se usa pero ha servido para debugguear
    public String getOrderText() {
        StringBuilder orderText = new StringBuilder();
        orderText.append("Pedido #").append(orderNumber).append("\n");
        
        for (Product product : products) {
            orderText.append(product.getName())
                    .append(" - ")
                    .append(product.getPrice() / 100.0)
                    .append("€\n");
        }
        
        orderText.append("\nTotal: ").append(getTotalAmount() / 100.0).append("€");
        return orderText.toString();
    }
    
    public int getTotalAmount() {
        int total = 0;
        for (Product product : products) {
            total += product.getPrice();
        }
        return total;
    }
    
    public int getOrderNumber() {
        return orderNumber;
    }
    
    public ArrayList<Product> getProducts() {
        return products; // Return a copy to maintain encapsulation
    }
}
