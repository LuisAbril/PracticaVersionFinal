package demo;

import java.io.IOException;


//Clase que inicia el programa
public class BurgerSelfOrderKioskMain {
    private final KioskManager manager;
    private final Context context;

    //Constructor que crea un nuevo Context(contiene toda la informacion necesaria para el pedido) y un KioskManager (controla el paso de las pantallas)
    public BurgerSelfOrderKioskMain() throws IOException {
        this.context = new Context(); // Initialize the application context
        this.manager = new KioskManager(context); // Pass context to KioskManager
    }

    // Muestra la primera pantalla
    public void run() {
        try {
            // Start the kiosk with the WelcomeScreen
            manager.start(); 
          //Control de erores
        } catch (IOException e) {
            System.err.println("Error during kiosk operation: " + e.getMessage());
        }
    }

    // Main de nuestra aplicacion
    public static void main(String[] args) {
        try {
            // Create and run the kiosk
            BurgerSelfOrderKioskMain kiosk = new BurgerSelfOrderKioskMain();
            kiosk.run();
          //Control de errores
        } catch (IOException e) {
            System.err.println("Error starting kiosk: " + e.getMessage());
        }
    }
}
