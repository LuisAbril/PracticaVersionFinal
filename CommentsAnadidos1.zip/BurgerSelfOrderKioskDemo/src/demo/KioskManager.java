package demo;

import screens.WelcomeScreen;
import java.io.IOException;
import screens.KioskScreen;

//Se encarga del movimiento de las pantallas
public class KioskManager {
    private final Context ctxt; // Contexto que contiene todas las dependencias del kiosco

    //constructor con la informacion del pedido
    public KioskManager(Context ctxt) {
        this.ctxt = ctxt;
    }

    //Muestra pantallas hasta que se cierra el programa
    public void start() throws IOException {
        // Crear y mostrar la pantalla de bienvenida (WelcomeScreen)
        KioskScreen nextScreen = new WelcomeScreen();
        while(true){
        nextScreen =  nextScreen.show(ctxt);
        }
    }
}
