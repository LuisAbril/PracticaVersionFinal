
package demo;

public interface Product {
    /**
     * Gets the price of the product in cents
     * @return price in cents
     */
    public int getPrice();
    
    /**
     * Gets the name of the product
     * @return product name
     */
    public String getName();
}
