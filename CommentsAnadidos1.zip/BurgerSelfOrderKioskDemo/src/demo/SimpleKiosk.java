package demo;

import java.util.ArrayList;
import sienens.BurgerSelfOrderKiosk;


//Sirve como "Servicio de llamada" a la interfaz otorgada en el enunciado BurgerSelfOrderKiosk 
public class SimpleKiosk {
    private BurgerSelfOrderKiosk kiosk;

    public SimpleKiosk(BurgerSelfOrderKiosk kiosk) {
        this.kiosk = kiosk;
    }

    public BurgerSelfOrderKiosk getKiosk() {
        return kiosk;
    }

    // Core functionalities of SimpleKiosk
    public void setOption(char key, String description) {
        // Implementation to set an option on the kiosk
        this.getKiosk().setOption(key, description);
        System.out.println("Setting option: " + key + " -> " + description);
    }

    public void setTitle(String title) {
        // Implementation to set the title
        this.getKiosk().setTitle(title);
        System.out.println("Setting title: " + title);
    }

    public void setDescription(String description) {
        // Implementation to set the description
        this.getKiosk().setDescription(description);
        System.out.println("Setting description: " + description);
    }

    public void setMode(int mode) {
        // Implementation to set the mode
        if (mode==0){
            this.getKiosk().setMenuMode();
        }else{this.getKiosk().setMessageMode();
        }
        System.out.println("Setting mode to: " + mode);
    }

    public void setImage(String imagePath) {
        // Implementation to set the image
        this.getKiosk().setImage(imagePath);
        System.out.println("Setting image: " + imagePath);
    }

    public char waitEvent(int timeout) {
        // Mock implementation of waiting for an event
        System.out.println("Waiting for an event for " + timeout + " seconds...");
        return 'A'; // Returning a mock input
    }

    public void print(ArrayList<String> message) {
        // Implementation for printing messages
        this.getKiosk().print(message);
        System.out.println("Printing: " + message);
    }

    public void retainCard(boolean retain) {
        // Implementation to retain the card
        this.getKiosk().retainCreditCard(retain);
        System.out.println("Retaining card: " + retain);
    }

    public void expelCreditCard(int reasonCode) {
        // Implementation to expel the card with a reason code
        this.getKiosk().expelCreditCard(reasonCode);
        System.out.println("Expelling card with reason code: " + reasonCode);
    }

    public void clearScreen() {
        // Clear all the screen components
        setTitle(null);
        setImage(null);
        setDescription(null);
        for (char cont = 'A'; cont <= 'H'; cont++) {
            setOption(cont, null);
        }
        System.out.println("Screen cleared.");
    }

    public long getCardNumber() {
        // Mock implementation to return a card number
        return this.getKiosk().getCardNumber();
    }
}
