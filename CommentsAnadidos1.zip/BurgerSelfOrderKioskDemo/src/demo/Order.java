package demo;

import java.util.ArrayList;

//Contiene un array de productos con los productos seleccionados por el usuario

public class Order {
    private int orderNumber;
    private ArrayList<Product> products;
    
    
   
    
    //añadir producto al pedido (pueden ser tanto individuales como menus)
    public void addfProduct(Product producto) {
        if (producto != null) {
            products.add(producto);
        }
    }
   
    
    
    
    
     //Constructores
    public Order(int orderNumber) {
        this.orderNumber = orderNumber;
        this.products = new ArrayList<>();
    }

    public Order() {
        this.products = new ArrayList<>();
    }
    
    
    
    //getters 
    public int getTotalAmount() {
        int total = 0;
        for (Product product : products) {
            total += product.getPrice();
        }
        return total;
    }
    
    public int getOrderNumber() {
        return orderNumber;
    }
    
    public ArrayList<Product> getProducts() {
        return products; 
    }
}
