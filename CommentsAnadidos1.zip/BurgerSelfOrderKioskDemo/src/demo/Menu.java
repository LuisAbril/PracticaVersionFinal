package demo;

import products.IndividualProduct;
import java.util.ArrayList;

//Contiene la funcionalidad de un menú como si fuese un producto individual

public class Menu implements Product {
    private double discount;
    private ArrayList<IndividualProduct> menuProducts;
    
    
    //constructor con descuento
    public Menu(int discount) {
        this.discount = discount;
        this.menuProducts = new ArrayList<>();
    }
    //constructor vacio
    public Menu() {
        menuProducts = new ArrayList<>();
    }
    
    
    //funcion para añadir producto al menu
    public void addProduct(IndividualProduct product) {
        menuProducts.add(product);
    }
    
    
    
    
    
    //getters y setters usados 
    //obtener el precio dle menu aplicando el descuento pasado
    public int getPrice(int discount) {
        int totalPrice = 0;     //inicializo el valor a devolver
        //Recorro todos los productos sumando sus respectivos precios
        for (IndividualProduct product : menuProducts) {
            totalPrice += product.getPrice();
        }
        //Se le aplica el descuento
        int precioFinalMenu = (int) (totalPrice * (1- (discount / 100)));
        return precioFinalMenu;  //Devolvemos el precio con el descuento aplicado
    }
    
 
    
    public ArrayList<IndividualProduct> getProducts() {
        ArrayList<IndividualProduct> nombres = new ArrayList<>();
        for (int i = 0;i<3;i++) {
            nombres.add(menuProducts.get(i));
        }
        return nombres;
    }
    


    public void setDiscount(int discount) {
        this.discount = discount;
    }

    @Override
    public int getPrice() {
        //no quiero esta funcion pq para obtener el precio le paso el descuento por parametro
        return 0;
    }

    @Override
    public String getName() {
        return "Implementa esta funcion";
    }
    
   

   
}