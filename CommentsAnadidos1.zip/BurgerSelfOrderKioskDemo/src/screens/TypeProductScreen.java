package screens;

import demo.Context;
import javax.swing.Timer;

public class TypeProductScreen implements KioskScreen {
    private static final int WAIT_TIME = 60;
    private String[] rutas;
    private int indice;

    @Override
    public KioskScreen show(Context context) {
        
        configureButtons(context);
        
        Timer timer = startImagePass(context);

        // Esperar la selección del usuario
        char selection = context.getKiosk().getKiosk().waitEvent(WAIT_TIME);
        return handleSelection(selection, context, timer);
    }

    private Timer startImagePass(Context context) {
        // Guardar las rutas de las tres imágenes obtenidas de los tipos de productos (del XML) en un array de Strings
        rutas = new String[]{"src/"+context.getMenu().getSectionsImg(0),
            "src/"+context.getMenu().getSectionsImg(1),
            "src/"+context.getMenu().getSectionsImg(2)};
        // Inicializar índice para el paso de las imagenes
        indice = 0;
        // Colocar la primera imagen
        context.getKiosk().setImage(rutas[indice]);
        // Inicializar timer para cambiar imagen cada 3 segundos
        Timer timer = new Timer(3000, e -> cambiarImagen(context));
        timer.start();
        return timer;
    }

    private void configureButtons(Context context) {
        context.getKiosk().clearScreen();
        context.getKiosk().setMode(0);   // Pantalla izquierda botones y derecha imagen
        context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(10));
        context.getKiosk().setOption('B', context.getTraductor().getCurrentDictionary().getFrase(17));
        context.getKiosk().setOption('C', context.getTraductor().getCurrentDictionary().getFrase(18));
        context.getKiosk().setOption('D', context.getTraductor().getCurrentDictionary().getFrase(19));
        context.getKiosk().setOption('E', context.getTraductor().getCurrentDictionary().getFrase(9));
    }


    // Función para actualizar la imagen
    private void cambiarImagen(Context context) {
        indice++;
        // Si se pasa del índice, volver al principio
        if (indice >= rutas.length) {
            indice = 0;
        }
        // Nueva imagen
        context.getKiosk().setImage(rutas[indice]);
    }

    private KioskScreen handleSelection(char selection, Context context, Timer timer) {
        timer.stop(); // Detener el temporizador al seleccionar una opción
        KioskScreen nextScreen;

        switch (selection) {
            case 'B' -> {// Navegar a la pantalla para el primer producto
                nextScreen = new ProductScreen(0);
            }
            case 'C' -> // Navegar a la pantalla para el segundo producto
                nextScreen = new ProductScreen(1);
            case 'D' -> // Navegar a la pantalla para el tercer producto
                nextScreen = new ProductScreen(2);
            case 'E' -> // Cancelar pedido y volver a la pantalla de pedidos
                nextScreen = new OrderScreen();
            default -> {
                // En caso de una opción no válida, volver a la pantalla inicial
                System.out.println("Hola!! Hay alguien ahí?");
                nextScreen = new WelcomeScreen();
            }
        }

        return nextScreen;
    }
}
