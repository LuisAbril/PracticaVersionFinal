package screens;

import demo.Context;
import demo.Menu;
import java.util.ArrayList;
import products.IndividualProduct;

//Pantalla de seleccion de menu
public class MenuScreen implements KioskScreen {
    private static final int WAIT_TIME = 60;
    private ArrayList<IndividualProduct> productsToChoose;
    private int indiceActual;
    Menu menu = new Menu();

    @Override
    public KioskScreen show(Context context) {
        //repetir la pantalla 3 veces
        for (int i=0; i<3;i++){
        boolean bucle =true;
        //cargar los productos que se van a mostrar
        productsToChoose = cargarTipos(context,i);
        //mostrar en pantalla los productos
        configureButtons(context,productsToChoose);
        
        // Esperar la selección del usuario y devolver la pantalla correspondiente
        while (bucle) { //Este buble se utiliza para asegurarnos que los botones presionados no son los de flecha adelante y flecha atras
            //Iniciar temporizador
            char selection = context.getKiosk().getKiosk().waitEvent(WAIT_TIME);
            //La vuelta será la siguiente pantalla a mostrar
            KioskScreen nextScreen = handleSelection(selection, context, productsToChoose,i==2);
            if (nextScreen != null) {
                bucle=false;  // Termina de seleccionar 1 producto
                if (nextScreen.getClass().equals(OrderScreen.class)||((nextScreen.getClass().equals(WelcomeScreen.class)))){return nextScreen;} //si es una pantalla la que devuelve esta última se muestra
            }
        }
        }
        return new OrderScreen();   //Aqui solo llega si se ha añadido un menu correctamente
    }

    private ArrayList<IndividualProduct> cargarTipos(Context context,int x) {
        // Inicializar la información que vamos a usar
        ArrayList<IndividualProduct>productos = new ArrayList<>();
        indiceActual = 0;
        for (int i = 0; i < context.getMenu().getSection(x).getProducts().size(); i++) {
            IndividualProduct producto = context.getMenu().getSection(x).getProduct(i);
            productos.add(producto);
        }
        return productos;
    }

    
    
    private void configureButtons(Context context,ArrayList<IndividualProduct> productos) {
        context.getKiosk().clearScreen();
        context.getKiosk().setMode(0);
        context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(20));
        context.getKiosk().setOption('C', context.getTraductor().getCurrentDictionary().getFrase(11));
        context.getKiosk().setOption('D', context.getTraductor().getCurrentDictionary().getFrase(9));
        context.getKiosk().setOption('E', context.getTraductor().getCurrentDictionary().getFrase(7));
        context.getKiosk().setOption('G', "<");
        context.getKiosk().setOption('H', ">");
        int dinero = productos.get(0).getPrice();
        double conversion = dinero/100.0;
        context.getKiosk().setDescription(productos.get(0).getName() + "\n" + productos.get(0).getDescription() + "\n" + conversion+"€");
        context.getKiosk().setImage("src/" + productos.get(0).getImage());
    }

    
    
    
    
    // Actualizar la pantalla con la información del producto actual
    private void actualizarPantalla(Context context, ArrayList<IndividualProduct> productos) {
        int dineroTotal = productos.get(indiceActual).getPrice();
        double conversion = dineroTotal/100.0;
        context.getKiosk().setDescription(productos.get(indiceActual).getName() + "\n" + productos.get(indiceActual).getDescription() + "\n" + conversion+"€");
        context.getKiosk().setImage("src/" + productos.get(indiceActual).getImage());
    }

    
    
    /**
     * Maneja la opción seleccionada por el usuario y devuelve la siguiente pantalla.
     */
    private KioskScreen handleSelection(char selection, Context context, ArrayList<IndividualProduct> productos,boolean esUltimo) {
        switch (selection) {
            case 'C' -> {
                menu.addProduct(productos.get(indiceActual));
                if (esUltimo){
                context.getOrder().addfProduct(menu);}
                return new PaymentScreen();  // Ir a la pantalla de orden
            }
            case 'D' -> {
                // Navegar a la pantalla para añadir un producto individual
                return new OrderScreen();
            }

            case 'E' -> {
                // Navegar a la pantalla de bienvenida
                return new WelcomeScreen();
            }

            case 'G' -> {
                // Navegar hacia atrás entre los productos
                indiceActual--;
                if (indiceActual < 0) {
                    indiceActual = productos.size() - 1;
                }
                actualizarPantalla(context, productos);
                return null;  // No hace nada más, sigue en la misma pantalla
            }
            case 'H' -> {
                // Navegar hacia adelante entre los productos
                indiceActual++;
                if (indiceActual >= productos.size()) {
                    indiceActual = 0;
                }
                actualizarPantalla(context, productos);
                return null;  // No hace nada más, sigue en la misma pantalla
            }
            default -> {
                System.out.println("¡Hola! ¿Hay alguien ahí?");
                return new WelcomeScreen();  // Volver a la pantalla de bienvenida
            }
        }
    }

    
    
}

