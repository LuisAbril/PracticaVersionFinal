package screens;

import demo.Context;


//Pantalla de seleccion de idiomas
public class IdiomScreen implements KioskScreen {
    private static final int WAIT_TIME = 60;

    @Override
    public KioskScreen show(Context context) {
        // Configurar botones
        configureScreenButtons(context);
        // Iniciar temporizador y esperar a que se presione algo
        char option = context.getKiosk().getKiosk().waitEvent(WAIT_TIME);
        handleLanguageSelection(option, context);
        // Volver a welcomeScreen
        return new WelcomeScreen();
    }
    
    private void configureScreenButtons(Context context) {
        context.getKiosk().clearScreen();
        context.getKiosk().setMode(0);
        context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase(24));
        context.getKiosk().setOption('A', context.getTraductor().getCurrentDictionary().getFrase(25));
        context.getKiosk().setOption('B', context.getTraductor().getCurrentDictionary().getFrase(26));
        context.getKiosk().setOption('C', context.getTraductor().getCurrentDictionary().getFrase(27));
        context.getKiosk().setOption('D', context.getTraductor().getCurrentDictionary().getFrase(28));
    }
    
    private void handleLanguageSelection(char option, Context context) {
        //Configuramos posibles opciones
        switch (option) {
            case 'A' -> context.getTraductor().setCurrentIdiom("esp");
            case 'B' -> context.getTraductor().setCurrentIdiom("fra");
            case 'C' -> context.getTraductor().setCurrentIdiom("ale");
            case 'D' -> context.getTraductor().setCurrentIdiom("ing");
        }
    }
}
