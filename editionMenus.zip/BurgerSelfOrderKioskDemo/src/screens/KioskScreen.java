package screens;

import demo.Context;

public interface KioskScreen {
    /**
     * Displays the screen using the dispenser interface
     * and handles user interaction
     * @param context The application context containing the kiosk/dispenser reference
     */
    KioskScreen show(Context context);
}