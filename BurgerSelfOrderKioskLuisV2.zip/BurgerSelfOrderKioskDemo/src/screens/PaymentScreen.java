package screens;

import demo.Context;

public class PaymentScreen implements KioskScreen {
    private static final int WAIT_TIME = 10;

    @Override
    public void show(Context context) {
        //limpiar pantalla
        this.clear(context);
        // Configurar el simulador para la pantalla de bienvenida
        context.getKiosk().setMessageMode();//modo abajo botones descripcion arriba
        context.getKiosk().setTitle("Inserte Tarjeta");//titulo
        //botones
        context.getKiosk().setOption('A', "Modificar");
        context.getKiosk().setOption('B', "CancelarPedido");
       

        // Esperar la selección del usuario
        char selection = context.getKiosk().waitEvent(WAIT_TIME);

        // Manejar la selección del usuario
        switch (selection) {
            case 'A' -> {
                System.out.println("Volver a la pantalla de pedido");
                OrderScreen orderScreen= new OrderScreen();
                orderScreen.show(context);
            }
            case 'B' -> {
                System.out.println("Cancelar el pedido");
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }
            default -> {
                System.out.println("Seleccion no valida. Recargando pantalla...");
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }
        }
    }
    //funcion para limpiar la informacion
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }
}