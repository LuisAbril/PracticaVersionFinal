package demo;

import products.IndividualProduct;
import java.util.ArrayList;
import java.util.List;

public class Menu implements Product {
    private int discount;
    private List<IndividualProduct> menuProducts;
    
    public Menu(int discount) {
        this.discount = discount;
        this.menuProducts = new ArrayList<>();
    }
    
    @Override
    public int getPrice() {
        int totalPrice = 0;
        for (IndividualProduct product : menuProducts) {
            totalPrice += product.getPrice();
        }
        return totalPrice - (totalPrice * discount / 100);  // Apply discount
    }
    
    public IndividualProduct getProduct(int numero) {
        if (numero >= 0 && numero < menuProducts.size()) {
            return menuProducts.get(numero);
        }
        return null;
    }
    
    public int getNumProducts() {
        return menuProducts.size();
    }
    
    @Override
    public String getName() {
        StringBuilder name = new StringBuilder("Menú: ");
        for (IndividualProduct product : menuProducts) {
            name.append(product.getName()).append(", ");
        }
        return name.substring(0, name.length() - 2); // Remove last comma and space
    }
    
    public void addProduct(IndividualProduct product) {
        menuProducts.add(product);
    }
}