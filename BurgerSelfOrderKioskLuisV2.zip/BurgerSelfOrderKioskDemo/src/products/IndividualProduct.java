package products;

import demo.Product;

public class IndividualProduct implements Product {
    //Atributos
    private String name;
    private String description;
    private String image;
    private int price;
    
    //Funcion para mostrar toda la informacion de los productos
    @Override
    public String toString() {
        return String.format("%s - %d€ - %s", 
            name, 
            price/100, // Convertir céntimos a euros
            description);
    }
    
    // Constructores
    public IndividualProduct(String name, String description, String image, int price) {
        this.name = name;
        this.description = description;
        this.image = image;
        this.price = price;
    }

    public IndividualProduct() {
    }
    
    // Getters y Setters
    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}