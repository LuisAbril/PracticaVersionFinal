package screens;

import demo.Context;
import demo.Order;

public class WelcomeScreen implements KioskScreen {
    private static final int WAIT_TIME = 60;

    @Override
    public KioskScreen show(Context context) {
        
        configureButtons(context);
        
        // Si hay un pedido con productos, se reinicia
        Order pedidoNuevo = new Order();
        context.setPedido(pedidoNuevo);
        
        // Esperar la selección del usuario
        char selection = context.getKiosk().waitEvent(WAIT_TIME);
        return handleSelection(selection, context);
    }

    private void configureButtons(Context context) {
        this.clear(context);
        context.getKiosk().setMenuMode();
        context.getKiosk().setTitle("URJC Burger - " + context.getTraductor().getCurrentDictionary().getFrase(0));
        context.getKiosk().setOption('B', context.getTraductor().getCurrentDictionary().getFrase(1));
        context.getKiosk().setOption('D', context.getTraductor().getCurrentDictionary().getFrase(2));
        context.getKiosk().setImage("src/PRODUCTOS/Logo.png");
    }

    // Función para limpiar la información
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }

    /**
     * Maneja la opción seleccionada por el usuario.
     *
     * @param selection Caracter seleccionado por el usuario
     * @param context Contexto del programa
     * @return La siguiente pantalla que se debe mostrar
     */
    private KioskScreen handleSelection(char selection, Context context) {
        KioskScreen nextScreen;

        switch (selection) {
            case 'B' -> // Navegar a la pantalla de pedidos
                nextScreen = new OrderScreen();
            case 'D' -> // Navegar a la pantalla para cambiar idioma
                nextScreen = new IdiomScreen();
            default -> {
                // En caso de una opción no válida, volver a la pantalla de bienvenida
                System.out.println("Hola!! Hay alguien ahí?");
                nextScreen = new WelcomeScreen();
            }
        }
        return nextScreen;
    }
}
