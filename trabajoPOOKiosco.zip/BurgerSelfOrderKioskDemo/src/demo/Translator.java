package demo;

import java.util.HashMap;
import java.util.Map;

//Traductor
public class Translator {
    private Map <String,String> palabras;

    
    public Translator() {
        palabras = new HashMap <>();
    }

    public String getFrase(String x) {
        return palabras.get(x);
    }

    public void setPalabras(String key, String value) {
        palabras.put(key, value);
    }
    
    
    
    
}
