package demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

//Traductor
public class TranslatorManager {
    //No estoy seguro como es esta informacion (quiero suponer que hay un map con todos los idiomas retenidos en cada objeto Translator)
    private Translator currentDictionary;
    private Map <String,Translator> dictionaries;

    public TranslatorManager() throws FileNotFoundException {
        dictionaries = new HashMap <>();
        
            //Crear los objetos
            Translator tradEsp = new Translator();
            Translator tradIng = new Translator();
            Translator tradFra = new Translator();
            Translator tradAle = new Translator();
            
            tradEsp = cargaDiccionario(tradEsp,"src/diccionarios/espanol.txt");
            tradIng = cargaDiccionario(tradIng,"src/diccionarios/ingles.txt");
            tradFra = cargaDiccionario(tradFra,"src/diccionarios/frances.txt");
            tradAle = cargaDiccionario(tradAle,"src/diccionarios/aleman.txt");
            
            //añadir los diccionarios al HashMap
            dictionaries.put("esp", tradEsp);
            dictionaries.put("ing", tradIng);
            dictionaries.put("fra", tradFra);
            dictionaries.put("ale", tradAle);
            
            currentDictionary = tradEsp;
    }
    
    
     // Método para cargar el diccionario desde el archivo
    public Translator cargaDiccionario(Translator trad, String ruta) throws FileNotFoundException {
        File file = new File(ruta);
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String linea = sc.nextLine();
                String[] partes = linea.split(";");  // Asumiendo que las líneas están separadas por comas
                
                // Validar que la línea se pueda dividir en exactamente dos partes
                if (partes.length == 2) {
                    String clave = partes[0].trim();  // Clave (por ejemplo, "1")
                    String valor = partes[1].trim();  // Valor (por ejemplo, "Bienvenido")
                    
                    trad.setPalabras(clave, valor);  // Añadir al mapa
                }
            }
        }
        return trad;
    }
    
    //Indica que la informacion que queremos esta en el Idioma X por lo que movemos el Translator del Map al currentDictionary
    public void setCurrentIdiom(String idioma){
        currentDictionary = dictionaries.get(idioma);
    }
    
    //devuelve una lista de todos los idiomas posibles (en este caso pasa las Keys del map y las mete en una lista
    public List getIdioms(){
        List <String> listaIdiomas = new ArrayList<>(dictionaries.keySet());
        return listaIdiomas;
    }

    public Translator getCurrentDictionary() {
        return currentDictionary;
    }
    
    
}