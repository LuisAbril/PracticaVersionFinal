package screens;

import demo.Context;
import demo.Order;

public class WelcomeScreen implements KioskScreen {
    private static final int WAIT_TIME = 60;

    @Override
    public KioskScreen show(Context context) {
        
        configureButtons(context);
        
        // Si hay un pedido con productos, se reinicia
        context.setPedido(new Order());
        
        // Esperar la selección del usuario
        char selection = context.getKiosk().getKiosk().waitEvent(WAIT_TIME);
        return handleSelection(selection, context);
    }

    private void configureButtons(Context context) {
        context.getKiosk().clearScreen();
        context.getKiosk().setMode(0);
        context.getKiosk().setTitle("URJC Burger - " + context.getTraductor().getCurrentDictionary().getFrase("Bienvenido"));
        context.getKiosk().setOption('B', context.getTraductor().getCurrentDictionary().getFrase("Nuevo pedido"));
        context.getKiosk().setOption('D', context.getTraductor().getCurrentDictionary().getFrase("Cambiar idioma"));
        context.getKiosk().setImage("src/PRODUCTOS/Logo.png");
    }
    /**
     * Maneja la opción seleccionada por el usuario.
     *
     * @param selection Caracter seleccionado por el usuario
     * @param context Contexto del programa
     * @return La siguiente pantalla que se debe mostrar
     */
    private KioskScreen handleSelection(char selection, Context context) {
        KioskScreen nextScreen;

        switch (selection) {
            case 'B' -> // Navegar a la pantalla de pedidos
                nextScreen = new OrderScreen();
            case 'D' -> // Navegar a la pantalla para cambiar idioma
                nextScreen = new IdiomScreen();
            default -> {
                // En caso de una opción no válida, volver a la pantalla de bienvenida
                System.out.println("Reiniciado el quiosco");
                nextScreen = new WelcomeScreen();
            }
        }
        return nextScreen;
    }
}
