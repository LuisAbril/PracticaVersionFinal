package screens;

import demo.Context;

public class OrderScreen implements KioskScreen {
    private static final int WAIT_TIME = 60;

    @Override
    public KioskScreen show(Context context) {
        configureButtons(context);

        // Esperar la selección del usuario
        char selection = context.getKiosk().getKiosk().waitEvent(WAIT_TIME);

        // Manejar la selección del usuario y devolver la siguiente pantalla
        return handleSelection(selection, context);
    }

    
    
    private void configureButtons(Context context) {
        context.getKiosk().clearScreen();
        context.getKiosk().setMode(0);
        context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase("Elige un Producto, Paga o Cancela"));
        context.getKiosk().setOption('B', context.getTraductor().getCurrentDictionary().getFrase("Añadir menú"));  
        context.getKiosk().setOption('C', context.getTraductor().getCurrentDictionary().getFrase("Añadir producto individual"));
        context.getKiosk().setOption('D', context.getTraductor().getCurrentDictionary().getFrase("Finaliza pedido y pagar"));
        context.getKiosk().setOption('E', context.getTraductor().getCurrentDictionary().getFrase("Cancelar pedido"));
        context.getKiosk().setImage("src/PRODUCTOS/Pedido.png");
    }

    
    private KioskScreen handleSelection(char selection, Context context) {
        KioskScreen nextScreen;

        switch (selection) {
            case 'B' -> // Navegar a la pantalla para añadir un menú
                nextScreen = new MenuScreen();
            case 'C' -> // Navegar a la pantalla para añadir un producto individual
                nextScreen = new TypeProductScreen();
            case 'D' -> // Navegar a la pantalla de pago
                nextScreen = new PaymentScreen();
            case 'E' -> // Cancelar pedido y volver a la pantalla inicial
                nextScreen = new WelcomeScreen();
            default -> {
                // En caso de una opción no válida, volver a la pantalla inicial
                System.out.println("Reiniciado el quiosco");
                nextScreen = new WelcomeScreen();
            }
        }

        return nextScreen;
    }
}
