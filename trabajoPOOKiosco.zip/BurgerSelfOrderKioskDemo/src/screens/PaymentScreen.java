package screens;

import demo.Context;
import demo.Menu;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.CommunicationException;
import products.IndividualProduct;

public class PaymentScreen implements KioskScreen {
    private static final int WAIT_TIME = 60;

    @Override
    public KioskScreen show(Context context) {
        
        int kioskNumber = 0;
        int orderNumber = 0;
        int discount = 0;
        int dineroTotal = getTotalPrecio(context,discount);
        double conversion = dineroTotal/100.0;
        int[]data = readFileKiosk(kioskNumber, orderNumber, discount, context);   
        discount = data[0];
        orderNumber = data[1];
        configureButtons(context, conversion);
        
        
        // Esperar la selección del usuario
        char selection = context.getKiosk().getKiosk().waitEvent(WAIT_TIME);

        // Manejar la selección del usuario
        return handleSelection(selection, context,discount,orderNumber,dineroTotal,conversion);
    }

    private int[] readFileKiosk(int kioskNumber, int orderNumber, int discount, Context context) throws NumberFormatException {
        File fichero = new File("src/demo/infoKiosk");
        Scanner scanner;
        try {
            scanner = new Scanner(fichero);
            scanner.useDelimiter(";");
            // Variables para almacenar los números
            
            
            // Leer las líneas y asignar los números a las variables
            if (scanner.hasNext()) {
                scanner.next(); // Lee "KioskNumber"
                if (scanner.hasNext()) {
                    kioskNumber = Integer.parseInt(scanner.next().trim()); // Asigna 5 a kioskNumber
                }
            }
            
            if (scanner.hasNext()) {
                scanner.next(); // Lee "OrderNumber"
                if (scanner.hasNext()) {
                    orderNumber = Integer.parseInt(scanner.next().trim()); // Asigna 21 a orderNumber
                }
            }
            
            if (scanner.hasNext()) {
                scanner.next(); // Lee "Discount"
                if (scanner.hasNext()) {
                    discount = Integer.parseInt(scanner.next().trim()); // Asigna 30 a discount
                }
            }
            scanner.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(PaymentScreen.class.getName()).log(Level.SEVERE, null, ex);
        }
        context.setKiosknumber(kioskNumber);
        context.setOrderNumber(orderNumber);
        return new int[] {discount,orderNumber};
    }


    private void configureButtons(Context context,double conversion) {
        context.getKiosk().clearScreen();
        context.getKiosk().setMode(1); // Modo abajo botones, descripción arriba
        context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase("Inserte tarjeta")); // Título
        context.getKiosk().setOption('A', context.getTraductor().getCurrentDictionary().getFrase("Modificar pedido"));
        context.getKiosk().setOption('B', context.getTraductor().getCurrentDictionary().getFrase("Cancelar pedido"));
        context.getKiosk().setDescription(getProductosResumen(context) + "\n" + context.getTraductor().getCurrentDictionary().getFrase("Precio total a pagar:") + conversion+"€");
    }


    private String getProductosResumen(Context context) {
        StringBuilder resumen = new StringBuilder();
        int totalPrecio = 0;
        
        // Obtener todos los productos del pedido
        for (Object product : context.getOrder().getProducts()) {
            if (product instanceof IndividualProduct) {
                // Producto individual
                IndividualProduct individualProduct = (IndividualProduct) product;
                resumen.append(context.getTraductor().getCurrentDictionary().getFrase("Producto Individual:")).append(individualProduct.getName()).append("\n");
            } else if (product instanceof Menu) {
                Menu menu = (Menu) product;
                resumen.append(context.getTraductor().getCurrentDictionary().getFrase("Menú:"));
                resumen.append("--");
                for (IndividualProduct individualProduct : menu.getProducts()) {
                    resumen.append(individualProduct.getName()).append("--");
                }
                resumen.append("\n");
            }
        }
        return resumen.toString(); // Devolver el resumen en forma de String
    }

    private int getTotalPrecio(Context context,int discount) {
        int totalPrecio = 0;

        // Obtener todos los productos del pedido
        for (Object product : context.getOrder().getProducts()) {
            if (product instanceof IndividualProduct) {
                // Producto individual
                IndividualProduct individualProduct = (IndividualProduct) product;
                totalPrecio += individualProduct.getPrice(); // Sumar el precio del producto individual
            } else if (product instanceof Menu) {
                Menu menu = (Menu) product;
                // Sumar el precio del menú, el descuento se selecciona en MenuScreen
                totalPrecio += menu.getPrice(discount);
            }
        }

        return totalPrecio; // Retornar el total de los precios sumados
    }

    private KioskScreen handleSelection(char selection, Context context,int discount,int orderNumber,int dineroTotal,double conversion) {
        KioskScreen nextScreen;
        if (selection == '1') {
            context.getKiosk().retainCard(false);
            try {
                
                boolean ok = context.getBank().doOperation(context.getKiosk().getCardNumber(), dineroTotal);
                context.getKiosk().clearScreen();
                
                if (ok) {
                    context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase("PAGO EXITOSO"));
                    context.getKiosk().setDescription(context.getTraductor().getCurrentDictionary().getFrase("Recoga el ticket con su número de pedido, retire su tarjeta y esté atento a la pantalla para recoger su pedido"));
                    context.getKiosk().expelCreditCard(100);
                    
                    // Creación del ticket e impresión
                    ArrayList<String> ticketText = new ArrayList<>();
                    ticketText.add(context.getTraductor().getCurrentDictionary().getFrase("Quiosco:") + context.getKioskNumber());
                    ticketText.add(context.getTraductor().getCurrentDictionary().getFrase("Número de pedido:") + context.getOrderNumber());
                    ticketText.add(getProductosResumen(context));
                    ticketText.add(context.getTraductor().getCurrentDictionary().getFrase("Precio total a pagar:") + conversion+"€");
                    
                    context.getKiosk().print(ticketText);
                    int newOrderNumber = orderNumber+5; 
                    if (newOrderNumber >=100){
                        newOrderNumber -= 100;
                    }
                    updateOrderNumberInFile("src/demo/infoKiosk",newOrderNumber);
                } else {
                    context.getKiosk().setTitle(context.getTraductor().getCurrentDictionary().getFrase("Problemas en el pago"));
                    context.getKiosk().setDescription(context.getTraductor().getCurrentDictionary().getFrase("Parece que no tienes suficiente dinero en la tarjeta"));
                    context.getKiosk().expelCreditCard(100);
                }
            } catch (IOException | CommunicationException ex) {
                Logger.getLogger(PaymentScreen.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        switch (selection) {
            case 'A' -> // Navegar a la pantalla de pedidos
                nextScreen = new OrderScreen();
            case 'B' -> // Navegar a la pantalla de bienvenida
                nextScreen = new WelcomeScreen();
            default -> {
                // En caso de una opción no válida, volver a la pantalla de bienvenida
                System.out.println("Reiniciado el quiosco");
                nextScreen = new WelcomeScreen();
            }
        }

        return nextScreen;
    }
    
    private void updateOrderNumberInFile(String filePath, int newOrderNumber) throws IOException {
        try {
            File fichero = new File(filePath);
            Scanner scanner = new Scanner(fichero);
            StringBuilder fileContent = new StringBuilder();
            
            // Leer el archivo y modificar el OrderNumber
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (line.contains("OrderNumber")) {
                    line = "OrderNumber; " + newOrderNumber+";"; // Modificar la línea que contiene "OrderNumber"
                }
                fileContent.append(line).append("\n");
            }
            
            // Escribir el contenido modificado de vuelta al archivo
            FileWriter writer = new FileWriter(fichero);
            writer.write(fileContent.toString());
            writer.close();
            
            scanner.close();
        } catch (FileNotFoundException e) {
            Logger.getLogger(PaymentScreen.class.getName()).log(Level.SEVERE, null, e);
        } catch (IOException e) {
            Logger.getLogger(PaymentScreen.class.getName()).log(Level.SEVERE, null, e);
        }
    }
}
