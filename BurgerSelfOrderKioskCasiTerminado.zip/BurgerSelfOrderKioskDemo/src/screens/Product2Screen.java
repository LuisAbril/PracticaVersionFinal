package screens;

import demo.Context;
import java.util.ArrayList;
import products.IndividualProduct;

public class Product2Screen implements KioskScreen {
    private static final int WAIT_TIME = 10;
    private ArrayList<IndividualProduct> productos;
    int indiceActual;

    @Override
    public void show(Context context) {
        //limpiar pantalla
        this.clear(context);
        //inicializar el array de hamburguesas
        productos = new ArrayList<>();
        indiceActual=0;
        // Configurar el simulador para la pantalla de pedido
        context.getKiosk().setMenuMode();   //Modo1 (botones a la izquierda img a la derecha)
        context.getKiosk().setTitle("Elige una Bebida");   //titulo
        //botones 
        context.getKiosk().setOption('C', "Añadir bebida al pedido");
        context.getKiosk().setOption('D', "Volver");
        context.getKiosk().setOption('E', "Cancelar pedido");
        context.getKiosk().setOption('G', "<");
        context.getKiosk().setOption('H', ">");

        //Inicializar la informacion que vamos a usar
        for (int i=0; i< context.getMenu().getSection(1).getProducts().size();i++){
            IndividualProduct producto = context.getMenu().getSection(1).getProduct(i);
            System.out.println(producto);
            productos.add(producto);
        }
        
        context.getKiosk().setDescription(productos.get(0).getName()+"\n"+productos.get(0).getDescription()+"\n"+productos.get(0).getPrice());
        context.getKiosk().setImage("src/"+productos.get(0).getImage());
        // Esperar la selección del usuario
        
        
        //bucle para que no se quede atascado despues de presionar una vez no dejen de funcionar los botones
        while (true) {
            System.out.println("Presiona una opción (G para anterior, H para siguiente): ");
            char selection = context.getKiosk().waitEvent(WAIT_TIME);
            handleSelection(selection, context, productos);
        }
        // Manejar la selección del usuario
        
    }
    
    //funcion para limpiar la informacion
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }
    
    
    private void actualizarPantalla(Context context, ArrayList<IndividualProduct> productos){
                context.getKiosk().setDescription(productos.get(indiceActual).getName()+"\n"+productos.get(indiceActual).getDescription()+"\n"+productos.get(indiceActual).getPrice());
                context.getKiosk().setImage("src/"+productos.get(indiceActual).getImage());
    }
    
    /**
     * Maneja la opción seleccionada por el usuario.
     *
     * @param selection Caracter seleccionado por el usuario
     * @param context Contexto del programa
     */
    private void handleSelection(char selection, Context context, ArrayList<IndividualProduct> productos) {
        switch (selection) {
            case 'C' -> {
                System.out.println("Opcion seleccionada: Anadir Producto");
                context.getOrder().addfProduct(productos.get(indiceActual));
                OrderScreen orderScreen = new OrderScreen();
                orderScreen.show(context);
            }
            case 'D' -> {
                System.out.println("Volver a los tipos");
            // Navegar a la pantalla para añadir un producto individual
                TypeProductScreen typeProductScreen = new TypeProductScreen();
                typeProductScreen.show(context);}
            case 'E' -> {
                System.out.println("Opcion seleccionada: Cancelar pedido");
            // Navegar a la pantalla de pago
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }
            case 'G' -> {
                System.out.println("Opcion seleccionada: Anterior producto");
                indiceActual--;
                if (indiceActual<0){indiceActual=productos.size()-1;}
                actualizarPantalla(context,productos);
            }
            case 'H' -> {
                System.out.println("Opcion seleccionada: Siguiente producto");
                indiceActual++;
                if (indiceActual>productos.size()-1){indiceActual=0;}
                actualizarPantalla(context,productos);
            }
            default -> {
                System.out.println("Seleccion no valida. Recargando pantalla...");
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }

        }
    }
}
