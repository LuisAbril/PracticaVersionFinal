package screens;

import demo.Context;

public class OrderScreen implements KioskScreen {
    private static final int WAIT_TIME = 10;

    @Override
    public void show(Context context) {
        //limpiar pantalla
        this.clear(context);
        // Configurar el simulador para la pantalla de pedido
        context.getKiosk().setMenuMode();   //Modo1 (botones a la izquierda img a la derecha)
        context.getKiosk().setTitle("Elige un Producto, Paga o Cancela");   //titulo
        //botones
        context.getKiosk().setOption('B', "Añadir menú a pedido");  
        context.getKiosk().setOption('C', "Añadir producto individual a pedido");
        context.getKiosk().setOption('D', "Finalizar pedido y pagar");
        context.getKiosk().setOption('E', "Cancelar pedido");
        //imagen
        context.getKiosk().setImage("src/PRODUCTOS/Pedido.png");

        // Esperar la selección del usuario
        char selection = context.getKiosk().waitEvent(WAIT_TIME);

        // Manejar la selección del usuario
        handleSelection(selection, context);
    }
    //funcion para limpiar la informacion
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }
    /**
     * Maneja la opción seleccionada por el usuario.
     *
     * @param selection Caracter seleccionado por el usuario
     * @param context Contexto del programa
     */
    private void handleSelection(char selection, Context context) {
        switch (selection) {
            case 'B' -> {
                System.out.println("Opcion seleccionada: Anadir menú a pedido");
            // Navegar a la pantalla para añadir un menú
                MenuScreen menuScreen = new MenuScreen();
                menuScreen.show(context);
            }
            case 'C' -> {
                System.out.println("Opcion seleccionada: Anadir producto individual a pedido");
            // Navegar a la pantalla para añadir un producto individual
                TypeProductScreen typeProductScreen = new TypeProductScreen();
                typeProductScreen.show(context);}
            case 'D' -> {
                System.out.println("Opcion seleccionada: Finalizar pedido y pagar");
            // Navegar a la pantalla de pago
                PaymentScreen paymentScreen = new PaymentScreen();
                paymentScreen.show(context);
            }
            case 'E' -> {
                System.out.println("Opcion seleccionada: Cancelar pedido");
                // Cancelar pedido y volver a la pantalla inicial
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }
            default -> {
                System.out.println("Seleccion no valida. Recargando pantalla...");
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }
        }
    }
}
