package screens;

import demo.Context;
import demo.Menu;
import java.util.ArrayList;
import products.IndividualProduct;

public class MenuScreen implements KioskScreen {
    private static final int WAIT_TIME = 10;
    private ArrayList<IndividualProduct> productos;
    int indiceActual;
    Menu menu = new Menu();

    // Vamos a almacenar los productos seleccionados por tipo
    private boolean[] productosSeleccionados = new boolean[3]; // 0 - hamburguesas, 1 - bebidas, 2 - complementos
    
    @Override
    public void show(Context context) {
        for (int x = 0; x < 3; x++) {  // Recorrer las tres secciones (hamburguesas, bebidas, complementos)
            // Limpiar pantalla
            this.clear(context);
            productos = new ArrayList<>();
            indiceActual = 0;
            
            // Configurar el simulador para la pantalla de pedido
            context.getKiosk().setMenuMode();   // Modo1 (botones a la izquierda, imagen a la derecha)
            context.getKiosk().setTitle("Elige  " + context.getMenu().getSectionsNames(x));   // Título

            // Botones 
            context.getKiosk().setOption('C', "Añadir al pedido");
            context.getKiosk().setOption('D', "Volver");
            context.getKiosk().setOption('E', "Cancelar pedido");
            context.getKiosk().setOption('G', "<");
            context.getKiosk().setOption('H', ">");

            // Inicializar la información que vamos a usar
            for (int i = 0; i < context.getMenu().getSection(x).getProducts().size(); i++) {
                IndividualProduct producto = context.getMenu().getSection(x).getProduct(i);
                productos.add(producto);
            }

            // Mostrar el primer producto de la sección
            context.getKiosk().setDescription(productos.get(0).getName() + "\n" + productos.get(0).getDescription()+"\n"+productos.get(0).getPrice());
            context.getKiosk().setImage("src/" + productos.get(0).getImage());

            // Bucle para esperar la selección del usuario
            while (true) {
                System.out.println("Presiona una opción (G para anterior, H para siguiente, C para añadir): ");
                char selection = context.getKiosk().waitEvent(WAIT_TIME);
                if (handleSelection(selection, context, productos, x)) {
                    break;  // Salir del bucle while cuando el producto se añade correctamente al menú o pedido
                }
            }
        }
    }

    // Función para limpiar la información
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);

        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }

    // Actualizar pantalla con el producto seleccionado
    private void actualizarPantalla(Context context, ArrayList<IndividualProduct> productos) {
        context.getKiosk().setDescription(productos.get(indiceActual).getName() + "\n" + productos.get(indiceActual).getDescription()+"\n"+productos.get(indiceActual).getPrice());
        context.getKiosk().setImage("src/" + productos.get(indiceActual).getImage());
    }

    // Maneja la opción seleccionada por el usuario
    private boolean handleSelection(char selection, Context context, ArrayList<IndividualProduct> productos, int x) {
        System.out.println(x);
        switch (selection) {
            case 'C': {
                System.out.println("Opción seleccionada: Añadir Producto");
                menu.addProduct(productos.get(indiceActual));  // Agregar producto al menú

                // Si ya hemos seleccionado un producto de cada tipo
                if (productosSeleccionados[0] && productosSeleccionados[1]) {
                    // Añadir el producto al pedido final
                    
                    context.getOrder().addfProduct(menu);
                    System.out.println("Producto añadido al pedido.");
                    System.out.println("NombreProducto: "+productos.get(indiceActual).getName());
                    System.out.println(menu.getName());
                    OrderScreen orderScreen = new OrderScreen();
                    orderScreen.show(context);
                } else {
                    // Si aún no se han seleccionado todos los productos de cada tipo
                    productosSeleccionados[x] = true;  // Marcar el tipo actual como seleccionado
                    System.out.println("NombreProducto: "+productos.get(indiceActual).getName());
                    
                    System.out.println("Producto añadido al menú.");
                }
                return true;  // Termina el bucle y va a la siguiente sección
            }
            case 'D': {
                System.out.println("Volver a los tipos");
                // Navegar a la pantalla para añadir un producto individual
                TypeProductScreen typeProductScreen = new TypeProductScreen();
                typeProductScreen.show(context);
                break;
            }
            case 'E': {
                System.out.println("Opción seleccionada: Cancelar pedido");
                // Navegar a la pantalla de bienvenida
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
                break;
            }
            case 'G': {
                System.out.println("Opción seleccionada: Anterior producto");
                indiceActual--;
                if (indiceActual < 0) {
                    indiceActual = productos.size() - 1;
                }
                actualizarPantalla(context, productos);
                break;
            }
            case 'H': {
                System.out.println("Opción seleccionada: Siguiente producto");
                indiceActual++;
                if (indiceActual >= productos.size()) {
                    indiceActual = 0;
                }
                actualizarPantalla(context, productos);
                break;
            }
            default: {
                System.out.println("Selección no válida. Recargando pantalla...");
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
                break;
            }
        }
        return false;  // No salir del bucle aún
    }
}