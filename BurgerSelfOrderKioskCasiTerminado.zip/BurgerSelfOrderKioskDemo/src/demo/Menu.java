package demo;

import products.IndividualProduct;
import java.util.ArrayList;

public class Menu implements Product {
    private int discount;
    private ArrayList<IndividualProduct> menuProducts;
    
    public Menu(int discount) {
        this.discount = discount;
        this.menuProducts = new ArrayList<>();
    }

    public Menu() {
        menuProducts = new ArrayList<>();
    }
    
    @Override
    public int getPrice() {
        int totalPrice = 0;
        for (IndividualProduct product : menuProducts) {
            totalPrice += product.getPrice();
        }
        return totalPrice - (totalPrice * discount / 100);  // Apply discount
    }
    
    public IndividualProduct getProduct(int numero) {
        if (numero >= 0 && numero < menuProducts.size()) {
            return menuProducts.get(numero);
        }
        return null;
    }
    public ArrayList<IndividualProduct> getProducts() {
        ArrayList<IndividualProduct> nombres = new ArrayList<>();
        for (int i = 0;i<3;i++) {
            nombres.add(menuProducts.get(i));
        }
        return nombres;
    }
    
    
    public int getNumProducts() {
        return menuProducts.size();
    }
    
    @Override
    public String getName() {
        StringBuilder name = new StringBuilder();
        for (int i=0; i<3;i++) {
            name.append(menuProducts.get(i).getName());
        }
        return name.toString(); 
    }
    
    public void addProduct(IndividualProduct product) {
        menuProducts.add(product);
    }

   
}