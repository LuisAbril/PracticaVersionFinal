package demo;
import java.util.ArrayList;
import java.util.List;

public class Order {
    private int orderNumber;
    private ArrayList<Product> products;
    
    
   
    
    
    public void addfProduct(Product producto) {
        if (producto != null) {
            products.add(producto);
        }
    }
   
    
    
    
    
     //Constructores
    public Order(int orderNumber) {
        this.orderNumber = orderNumber;
        this.products = new ArrayList<>();
    }

    public Order() {
        this.products = new ArrayList<>();
    }
    
    
    
    //getters 
    public String getOrderText() {
        StringBuilder orderText = new StringBuilder();
        orderText.append("Pedido #").append(orderNumber).append("\n");
        
        for (Product product : products) {
            orderText.append(product.getName())
                    .append(" - ")
                    .append(product.getPrice() / 100.0)
                    .append("€\n");
        }
        
        orderText.append("\nTotal: ").append(getTotalAmount() / 100.0).append("€");
        return orderText.toString();
    }
    
    
    
    public int getTotalAmount() {
        int total = 0;
        for (Product product : products) {
            total += product.getPrice();
        }
        return total;
    }
    
    public int getOrderNumber() {
        return orderNumber;
    }
    
    public ArrayList<Product> getProducts() {
        return products; // Return a copy to maintain encapsulation
    }
}
