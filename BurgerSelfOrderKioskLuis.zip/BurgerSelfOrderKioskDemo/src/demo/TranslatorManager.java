/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author abril
 */
public class TranslatorManager {
    //No estoy seguro como es esta informacion (quiero suponer que hay un map con todos los idiomas retenidos en cada objeto Translator)
    private Translator currentDictionary;
    private Map <String,Translator> dictionaries;

    public TranslatorManager() {
        currentDictionary = new Translator();
    }
    
    //Indica que la informacion que queremos esta en el Idioma X por lo que movemos el Translator del Map al currentDictionary
    public void setCurrentIdiom(String idioma){
        currentDictionary = dictionaries.get(idioma);
    }
    
    //devuelve una lista de todos los idiomas posibles (en este caso pasa las Keys del map y las mete en una lista
    public List getIdioms(){
        List <String> listaIdiomas = new ArrayList<>(dictionaries.keySet());
        return listaIdiomas;
    }
    
}