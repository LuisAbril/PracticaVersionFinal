package screens;

import demo.Context;
import javax.swing.Timer;



public class TypeProductScreen implements KioskScreen{
    private static final int WAIT_TIME = 10;
    private String[] rutas;
    private int indice;

    @Override
    public void show(Context context) {
        //limpiar pantalla
        this.clear(context);
        // Configurar el simulador para la pantalla de pedido
        context.getKiosk().setMenuMode();   //pantalla izquierda botones y derecha imagen
        //titulo
        context.getKiosk().setTitle("Seleccione el tipo de producto:");
        //botones
        context.getKiosk().setOption('B', context.getMenu().getSectionsNames(0));
        context.getKiosk().setOption('C', context.getMenu().getSectionsNames(1));
        context.getKiosk().setOption('D', context.getMenu().getSectionsNames(2));
        context.getKiosk().setOption('E', "Volver");
        
        //guardo las rutas de las tres  imagenes obtenidas de los tipos de prods (del XML) en un array de Strings
        rutas = new String[]{"src/"+context.getMenu().getSectionsImg(0),"src/"+context.getMenu().getSectionsImg(1),"src/"+context.getMenu().getSectionsImg(2)};
        //inicializar indice
        indice=0;
        //colocar la primera imagen(ns pq pero si no, los primeros segundos no hay imagen establecida)
        context.getKiosk().setImage(rutas[indice]);
        //inicializar timer
        Timer timer = new Timer(3000,e->cambiarImagen(context));
        timer.start();
        
        // Esperar la selección del usuario
        char selection = context.getKiosk().waitEvent(WAIT_TIME);

        // Manejar la selección del usuario
        handleSelection(selection, context,timer);
    }
    //funcion para limpiar la informacion
    private void clear(Context context) {
        context.getKiosk().setTitle(null);
        context.getKiosk().setImage(null);
        context.getKiosk().setDescription(null);
        
        for (char cont = 'A'; cont <= 'H'; cont++) {
            context.getKiosk().setOption(cont, null);
        }
    }
    //funciona para actualizar la imagen
    private void cambiarImagen(Context context){
        indice++;
        //si se pasa del indice, volver al principio
        if (indice>=rutas.length){indice=0;}
        //nueva imagen
        context.getKiosk().setImage(rutas[indice]);
    }
    
    
    
    
    /**
     * Maneja la opción seleccionada por el usuario.
     *
     * @param selection Caracter seleccionado por el usuario
     * @param context Contexto del programa
     */
    private void handleSelection(char selection, Context context,Timer timer) {
       timer.stop();
        switch (selection) {
            
            case 'B' -> System.out.println("Opcion seleccionada: Tipo0");
            
            case 'C' -> System.out.println("Opcion seleccionada: Tipo1");
            
            case 'D' -> System.out.println("Opcion seleccionada: Tipo2");
            
            case 'E' -> {
                System.out.println("Opcion seleccionada: Volver");
                // Cancelar pedido y volver a la pantalla inicial
                OrderScreen orderScreen = new OrderScreen();
                orderScreen.show(context);
            }
            default -> {
                System.out.println("Seleccion no valida. Recargando pantalla...");
                WelcomeScreen welcomeScreen = new WelcomeScreen();
                welcomeScreen.show(context);
            }
        }
    }
}

