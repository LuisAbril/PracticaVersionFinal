package products;


import java.util.ArrayList;

public class MenuCardSection {
    //Atributos
    private String name;
    private String image;
    private ArrayList<IndividualProduct> products;

    //Funcion para mostrar todos los productos
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Sección: ").append(name).append("\n");
        sb.append("Imagen: ").append(image).append("\n");
        sb.append("Productos: ").append(products.size()).append("\n");
        for (IndividualProduct product : products) {
            sb.append("  - ").append(product.toString()).append("\n");
        }
        return sb.toString();
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    // Constructores
    public MenuCardSection( String name, String image, ArrayList<IndividualProduct> products) {
        this.name = name;
        this.image = image;
        this.products = products;
    }

    public MenuCardSection() {
    }
    
    // Getters y Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public ArrayList<IndividualProduct> getProducts() {
        return products;
    }

    public void setProducts(ArrayList<IndividualProduct> products) {
        this.products = products;
    }
}
